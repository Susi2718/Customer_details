import Controller from '@ember/controller';
import { action } from '@ember/object';
import { tracked } from '@glimmer/tracking';
import { inject as service } from '@ember/service';
import { computed } from '@ember/object';
export default class ContactNewController extends Controller {
  @service store;
  @service router;
  @service DropDown;

  @tracked id;
  @tracked model;
  @tracked buttonText;
  @tracked Gender = this.DropDown.Gender;

  @computed('Gender', 'model')
  get title() {
    console.log(this.Gender);
    let data = this.model;
    if (data.id) {
      this.buttonText = 'Update';
      return 'Edit contact';
    } else {
      this.buttonText = 'Save';
      return 'Add new contact';
    }
  }

  @action
  async addNew(event) {
    let formdata = this.model;
    event.preventDefault();
    // console.log(formdata.validate());
    // console.log({ errors: formdata.get('errors') });
    if (await formdata.validate()) {
      if (formdata.id) {
        // await this.store
        //   .findRecord('contact', formdata.id)
        //   .then(function (contactreturned) {
        //     contactreturned = formdata;
        //     contactreturned.save();
        //   });
        formdata.save();
        return this.router.transitionTo('contact', {
          queryParams: { id: formdata.id },
        });
      } else {
        let id = 0;
        //const contact = this.store.createRecord('contact', formdata);
        await formdata.save().then(function (contactreturned) {
          id = contactreturned.id;
        });
        return this.router.transitionTo('contact', { queryParams: { id: id } });
      }
    } else {
      console.log(formdata.get('errors'));
    }
  }

  @action
  backtoContact() {
    this.router.transitionTo('contact');
  }

  @action ongenderchange(event) {
    this.model.gender = event.target.value;
    // console.log(event.target.value)
    console.log(this.model.gender);
  }
}
