import JSONAPISerializer from '@ember-data/serializer/json-api';

export default class ContactSerializer extends JSONAPISerializer {}
