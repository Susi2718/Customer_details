import JSONAPISerializer from '@ember-data/serializer/json-api';

export default class GenderSerializer extends JSONAPISerializer {}
